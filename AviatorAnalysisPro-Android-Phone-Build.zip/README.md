# Aviator Analysis Pro — Android source project

A native Android app for manually recording Aviator multipliers, viewing round history, basic statistics and a chart, and tracking personal risk limits.

## Features
- Add and locally save multiplier history (up to 1,000 rounds).
- History list with timestamps and clear-history action.
- Average, highest, lowest, multiplier distribution, and a recent-round chart.
- Editable bankroll, maximum session loss, and profit target.
- Dark, airplane/crash-game-inspired interface.
- No network access, betting automation, account login, or claims of predicting future rounds.

## Build an APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete (internet is needed for first-time Gradle dependency downloads).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The source project is included so it can be built in Android Studio.

## Important limitation
Aviator outcomes cannot be reliably predicted from past multipliers. Statistics describe only recorded rounds and are not betting signals or guarantees. Use risk limits for budgeting, not as a promise of profit.

## Phone-only cloud build (GitHub Actions)
This ZIP also includes `.github/workflows/build-apk.yml` to build the APK on a GitHub-hosted runner.

1. On your phone, sign in to GitHub and create a **new repository**. For simplest setup, choose Public; avoid uploading personal secrets.
2. Extract this ZIP using your phone's file manager.
3. Upload the extracted project files and folders into the repository, preserving the `.github/workflows/build-apk.yml` path. GitHub's mobile web interface may make folder uploads awkward; if needed, use GitHub's web upload page in Chrome with Desktop site enabled.
4. Open the repository's **Actions** tab. Choose **Build Aviator Analysis Pro APK** and tap **Run workflow** (or push/commit files to `main` to trigger it).
5. Wait for the workflow to finish successfully. Open the completed run, find **Artifacts**, and download `AviatorAnalysisPro-debug-apk`.
6. Extract that artifact ZIP to obtain `app-debug.apk`, then tap the APK in your Downloads app to install it. Android may ask you to allow installs from that source.

The APK is a debug build intended for personal testing. GitHub Actions is a cloud build runner; this workflow has not been executed here, so the APK is not yet built or verified.
