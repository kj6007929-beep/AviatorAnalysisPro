package com.example.aviatoranalysispro

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 15, 30)
    private val panel = Color.rgb(12, 29, 49)
    private val red = Color.rgb(255, 35, 78)
    private val green = Color.rgb(0, 220, 145)
    private val white = Color.rgb(239, 245, 255)
    private val muted = Color.rgb(153, 177, 205)
    private val prefs by lazy { getSharedPreferences("aviator_data", MODE_PRIVATE) }
    private val rounds = mutableListOf<Round>()
    private var balance = 100.0
    private var maxLoss = 20.0
    private var targetProfit = 50.0
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout

    data class Round(val multiplier: Double, val time: Long)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        showHome()
    }

    private fun loadData() {
        balance = prefs.getString("balance", "100")?.toDoubleOrNull() ?: 100.0
        maxLoss = prefs.getString("maxLoss", "20")?.toDoubleOrNull() ?: 20.0
        targetProfit = prefs.getString("targetProfit", "50")?.toDoubleOrNull() ?: 50.0
        val arr = try { JSONArray(prefs.getString("rounds", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            rounds.add(Round(o.optDouble("m", 0.0), o.optLong("t", System.currentTimeMillis())))
        }
    }

    private fun saveData() {
        val arr = JSONArray()
        rounds.forEach { r -> arr.put(JSONObject().put("m", r.multiplier).put("t", r.time)) }
        prefs.edit().putString("rounds", arr.toString())
            .putString("balance", balance.toString()).putString("maxLoss", maxLoss.toString())
            .putString("targetProfit", targetProfit.toString()).apply()
    }

    private fun startScreen(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 16, 18, 10) }
        val header = TextView(this).apply {
            text = "✈  AVIATOR ANALYSIS PRO\n$title"
            setTextColor(red); textSize = 22f; gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 8, 4, 18); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 10, 0, 0) }
        listOf("Home", "History", "Stats", "Risk").forEach { label ->
            val b = Button(this).apply { text = label; textSize = 11f; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel)) }
            b.setOnClickListener { when(label) { "Home" -> showHome(); "History" -> showHistory(); "Stats" -> showStats(); else -> showRisk() } }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); setBackgroundColor(panel)
        }
        box.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(muted) })
        box.addView(TextView(this).apply { text = body; textSize = 19f; setTextColor(white); setPadding(0, 6, 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 10
        content.addView(box, lp)
    }

    private fun field(hint: String, value: String = ""): EditText {
        return EditText(this).apply {
            this.hint = hint; setSingleLine(true); setText(value); textSize = 16f; setTextColor(white)
            setHintTextColor(muted); setPadding(12, 8, 12, 8)
            backgroundTintList = android.content.res.ColorStateList.valueOf(muted)
        }
    }

    private fun action(label: String, onClick: () -> Unit) {
        val b = Button(this).apply { text = label; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)) }
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 10
        content.addView(b, lp)
    }

    private fun statsLine(): String {
        if (rounds.isEmpty()) return "Rounds: 0   •   Average: —   •   Highest: —"
        val values = rounds.map { it.multiplier }
        return "Rounds: ${values.size}   •   Avg: ${"%.2f".format(values.average())}x\nHighest: ${"%.2f".format(values.maxOrNull())}x   •   Lowest: ${"%.2f".format(values.minOrNull())}x"
    }

    private fun showHome() {
        startScreen("Track • Analyze • Manage")
        card("ROUND SUMMARY", statsLine())
        card("IMPORTANT", "This app analyzes entered past results. It cannot know or guarantee the next crash multiplier.")
        val entry = field("Enter multiplier (example: 2.35)")
        content.addView(entry)
        action("ADD ROUND") {
            val v = entry.text.toString().trim().removeSuffix("x").toDoubleOrNull()
            if (v == null || v < 1.0 || v > 1000000.0) {
                Toast.makeText(this, "Enter a valid multiplier of 1.00 or higher", Toast.LENGTH_SHORT).show()
            } else {
                rounds.add(0, Round(v, System.currentTimeMillis()))
                if (rounds.size > 1000) rounds.removeAt(rounds.lastIndex)
                saveData(); showHome()
            }
        }
        action("VIEW ROUND HISTORY") { showHistory() }
        action("STATISTICS & CHART") { showStats() }
        action("RISK MANAGEMENT") { showRisk() }
    }

    private fun showHistory() {
        startScreen("Round History")
        if (rounds.isEmpty()) card("NO DATA YET", "Add multipliers on the Home screen to begin tracking.")
        rounds.take(250).forEachIndexed { idx, r ->
            val stamp = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(r.time))
            card("#${rounds.size - idx}  •  $stamp", String.format(Locale.US, "%.2fx", r.multiplier))
        }
        if (rounds.isNotEmpty()) action("CLEAR ALL HISTORY") {
            rounds.clear(); saveData(); showHistory()
        }
    }

    private fun showStats() {
        startScreen("Statistics & Charts")
        val values = rounds.map { it.multiplier }
        card("ALL RECORDED ROUNDS", statsLine())
        if (values.isNotEmpty()) {
            val low = values.count { it < 2.0 }
            val mid = values.count { it >= 2.0 && it < 10.0 }
            val high = values.count { it >= 10.0 }
            card("MULTIPLIER DISTRIBUTION", "Below 2x: $low (${pct(low, values.size)})\n2x to below 10x: $mid (${pct(mid, values.size)})\n10x or above: $high (${pct(high, values.size)})")
            content.addView(MultiplierChart(values.take(50).reversed()), LinearLayout.LayoutParams(-1, 210))
            card("LAST 10 ROUNDS", values.take(10).joinToString("   ") { String.format(Locale.US, "%.2fx", it) })
        } else card("NO DATA", "Record some rounds to see statistics and the chart.")
        card("HOW TO READ THIS", "These are descriptions of recorded history only. They do not establish a reliable pattern for future rounds.")
    }

    private fun pct(n: Int, total: Int) = String.format(Locale.US, "%.1f%%", n * 100.0 / total)

    private fun showRisk() {
        startScreen("Risk Management")
        card("PLAY SMART", "Set limits before playing. Never risk money you cannot afford to lose.")
        val balanceField = field("Starting balance / bankroll", balance.toString())
        val lossField = field("Maximum session loss", maxLoss.toString())
        val targetField = field("Profit target (tracking only)", targetProfit.toString())
        content.addView(balanceField); content.addView(lossField); content.addView(targetField)
        action("SAVE RISK LIMITS") {
            val b = balanceField.text.toString().toDoubleOrNull()
            val l = lossField.text.toString().toDoubleOrNull()
            val t = targetField.text.toString().toDoubleOrNull()
            if (b == null || l == null || t == null || b < 0 || l < 0 || t < 0) {
                Toast.makeText(this, "Enter valid non-negative numbers", Toast.LENGTH_SHORT).show()
            } else {
                balance = b; maxLoss = l; targetProfit = t; saveData()
                Toast.makeText(this, "Risk limits saved", Toast.LENGTH_SHORT).show()
                showRisk()
            }
        }
        card("YOUR LIMITS", "Bankroll: ${"%.2f".format(balance)}\nMax loss: ${"%.2f".format(maxLoss)}\nProfit target: ${"%.2f".format(targetProfit)}")
        card("RESPONSIBLE PLAY", "Use a fixed budget, avoid chasing losses, and stop when you reach your limit. The app does not place bets or connect to Aviator.")
    }

    inner class MultiplierChart(private val values: List<Double>) : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(panel)
            val left = 42f; val right = width - 16f; val top = 18f; val bottom = height - 28f
            p.color = muted; p.strokeWidth = 1f; p.textSize = 11f
            for (i in 0..4) {
                val y = bottom - (bottom - top) * i / 4f
                canvas.drawLine(left, y, right, y, p)
                canvas.drawText("${i * 5}x", 4f, y + 4f, p)
            }
            if (values.isEmpty()) return
            val max = maxOf(5.0, values.maxOrNull() ?: 5.0)
            val slot = (right - left) / values.size
            values.forEachIndexed { i, v ->
                val x = left + i * slot + slot * 0.12f
                val barTop = bottom - ((v.coerceAtMost(max) / max) * (bottom - top)).toFloat()
                p.color = if (v >= 10) red else green
                canvas.drawRect(x, barTop, x + slot * 0.72f, bottom, p)
            }
        }
    }
}
